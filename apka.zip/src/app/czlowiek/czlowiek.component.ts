import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-czlowiek',
  templateUrl: './czlowiek.component.html',
  styleUrls: ['./czlowiek.component.scss']
})
export class CzlowiekComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
